PDF2Keynote meets the needs for LaTeX/beamer presentations on a Mac equipped
with Kexynote - why not use Keynote to present (support for two displays
and all the other niceties...)

- output will be 1024x768
- optimally one should build the beamer-PDF with \documentclass[trans]{beamer}
  to suppres the navigation bar (which cannot be used in Keynote, anyway)  

INSTALL:
1. copy the folder PDF2Keynote to /Users/Shared
2. open PDF2KeynoteRunAll in Automator (not the 'Automator Launcher')
3. Save PDF2KeynoteRunAll as Plug-In for Finder (name it something like 
   PDF2Keynote)
4. right-click on a beamer-PDF and choose Automator -> PDF2Keynote


author: egon w. stemle <egon.stemle@uos.de>
